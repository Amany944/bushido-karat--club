---
name: Bushido Modern
colors:
  surface: '#1a1a1a'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#ebbbb4'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#b18780'
  outline-variant: '#603e39'
  surface-tint: '#ffb4a8'
  primary: '#ffb4a8'
  on-primary: '#690100'
  primary-container: '#ff5540'
  on-primary-container: '#5c0000'
  inverse-primary: '#c00100'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#acc7ff'
  on-tertiary: '#002f67'
  tertiary-container: '#488fff'
  on-tertiary-container: '#00285b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930100'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#d7e2ff'
  tertiary-fixed-dim: '#acc7ff'
  on-tertiary-fixed: '#001a40'
  on-tertiary-fixed-variant: '#004491'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  border-low: '#333333'
  text-dim: '#a0a0a0'
typography:
  display-xl:
    fontFamily: Bebas Neue
    fontSize: 96px
    fontWeight: '400'
    lineHeight: 100%
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Bebas Neue
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 110%
    letterSpacing: 0.03em
  headline-lg-mobile:
    fontFamily: Bebas Neue
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 110%
  headline-md:
    fontFamily: Bebas Neue
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 120%
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 160%
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 160%
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 100%
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-sm: 16px
  margin-md: 40px
  margin-lg: 80px
---

## Brand & Style

The design system is a fusion of traditional martial arts discipline and high-end modern digital aesthetics. It targets a serious, dedicated audience seeking mastery and precision. The emotional response is one of focus, power, and quiet confidence.

The visual style is **Minimalist with High-Contrast**. It leverages expansive negative space (ma) to allow content to breathe, mirroring the focus of a dojo. The interface is characterized by raw, monochromatic foundations punctuated by aggressive, high-energy accents. It avoids unnecessary decoration, favoring structural integrity and thin, precise "ghost borders" that define space without cluttering it.

## Colors

The palette is rooted in a deep, nocturnal foundation. **Deep Black (#0a0a0a)** serves as the primary canvas, creating an infinite void that emphasizes focus. **Martial Red (#ff0000)** is used sparingly but with maximum impact—reserved for primary calls to action, active states, and critical highlights.

**Pure White (#ffffff)** provides the high-contrast clarity required for legible typography and iconography. **Surface Gray (#1a1a1a)** is used for secondary containers and cards to create subtle depth against the black background. A tertiary **Border Gray (#333333)** is employed for thin, structural outlines that maintain the minimalist rigor.

## Typography

The typographic hierarchy is built on extreme contrast between the imposing, tall forms of **Bebas Neue** and the utilitarian precision of **Inter**. 

Headlines must feel monumental. Use `display-xl` for hero sections with slight letter spacing to increase the sense of "presence." All headlines should be treated as architectural elements. Body text remains neutral and highly legible, using `Inter` with generous line height to ensure readability against the dark background. Labels and small navigation elements use uppercase Inter with increased letter spacing to mirror the rhythmic precision of kata.

## Layout & Spacing

This design system utilizes a **Fixed Grid** on desktop (12 columns) and a **Fluid Grid** on mobile (4 columns). The layout philosophy is defined by "asymmetric balance"—using large margins and offset containers to create dynamic visual paths.

- **Desktop:** 1280px max-width container with 80px side margins for a focused, cinematic feel.
- **Tablet:** 768px-1024px, 8 columns, 40px margins.
- **Mobile:** <767px, 4 columns, 16px margins. 

Spacing follows a strict 8px base unit. Use generous vertical padding (`margin-lg`) between sections to enforce the minimalist aesthetic and prevent the UI from feeling crowded.

## Elevation & Depth

Depth is not communicated through shadows, but through **Tonal Layering** and **Material Translucency**. 

- **Background:** The base level is always `#0a0a0a`.
- **Containers:** Modular cards and sections sit on `#1a1a1a`. 
- **Ghost Borders:** Instead of shadows, use 1px solid borders in `#333333` to define edges.
- **Glassmorphism:** Navigation bars and overlays use a backdrop filter (blur: 12px) with a semi-transparent `#0a0a0a` (60% opacity) fill to maintain a sense of environmental awareness.

## Shapes

The shape language is strictly **Sharp (0px)**. This reflects the "cut" of a blade and the uncompromising nature of martial arts. Do not use border-radii on buttons, cards, or input fields. The only exception is for circular avatars or specific functional icons. This lack of rounding reinforces the modern, architectural, and "hard" aesthetic of the system.

## Components

### Buttons
Primary buttons are solid `Martial Red` with `Pure White` text. No border-radius. Hover states should invert the colors or move to a slightly darker red. Ghost buttons use a 1px `Pure White` border and white text.

### Modular Training Cards
Cards use the `Surface Gray` background with a 1px `Border Gray` ghost border. Content should be heavily inset. Use `Bebas Neue` for card titles to maintain the imposing tone.

### Navbar
The navbar is fixed to the top of the viewport. It utilizes a background blur with a thin `Border Gray` bottom stroke. Navigation links are `label-sm` (uppercase Inter) and transition to `Martial Red` on hover.

### Timeline Biography
A vertical line (1px, `Border Gray`) runs through the center or left-aligned. Timeline nodes are sharp squares (8px x 8px) in `Martial Red`. Dates use `Bebas Neue`.

### Input Fields
Inputs are transparent with a 1px bottom border in `Border Gray`. Upon focus, the border transitions to `Martial Red`. Placeholder text is `text-dim`.

### Accordion FAQ
Clean, horizontal rows separated by 1px `Border Gray` lines. The expansion icon is a thin plus/minus sign. Titles are `body-lg` in `Pure White`.