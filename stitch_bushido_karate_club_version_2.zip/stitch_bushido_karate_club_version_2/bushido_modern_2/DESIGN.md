---
name: Bushido Modern
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e3beb8'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#aa8984'
  outline-variant: '#5a403c'
  surface-tint: '#ffb4a8'
  primary: '#ffb4a8'
  on-primary: '#690000'
  primary-container: '#8b0000'
  on-primary-container: '#ff907f'
  inverse-primary: '#b52619'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#414343'
  on-tertiary-container: '#afafb0'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#920703'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Bebas Neue
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 80px
    letterSpacing: 2px
  headline-lg:
    fontFamily: Bebas Neue
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 1px
  headline-lg-mobile:
    fontFamily: Bebas Neue
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 1px
  headline-md:
    fontFamily: Bebas Neue
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.5px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 1px
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style
The design system embodies the philosophy of *Bushido*: discipline, precision, and restrained power. It bridges the gap between ancient martial tradition and a modern, high-end athletic lifestyle. The aesthetic is **Minimalist High-Contrast**, leaning into a cinematic experience that prioritizes focus and intentionality.

The target audience consists of serious practitioners and individuals seeking a premium, professional environment. The emotional response should be one of respect, intensity, and clarity. To achieve this, the system utilizes vast amounts of negative space (Ma), sharp edges, and a restricted color palette that allows photography—specifically high-contrast, black-and-white, or desaturated action shots—to provide the visual energy.

## Colors
The palette is rooted in the "Dark Mode" aesthetic to create a focused, dojo-like atmosphere. 

- **Primary Background (#0A0A0A):** A deep, near-black that provides an infinite canvas, representing the "Void" and depth of mastery.
- **Accent Burgundy (#8B0000):** Used sparingly for primary actions, critical highlights, and symbolic elements. It represents blood, heart, and the rising sun.
- **Surface Anthracite (#1A1A1A):** Used for cards, sections, and containers to create subtle depth against the primary background without breaking the dark immersion.
- **High-Contrast White (#FFFFFF):** Reserved for essential typography and icons to ensure maximum legibility and a striking visual rhythm.

## Typography
Typography is the primary driver of the "Traditional meets Modern" narrative. 

**Headlines** use *Bebas Neue* to mimic the verticality and impact of Japanese calligraphy. These should always be uppercase and treated as structural elements. Large "Display" sizes should be used for hero sections with tight line-heights to maintain a sense of compressed power.

**Body Text** utilizes *Inter* for its clinical, modern precision. It provides the necessary functional balance to the expressive headlines. Maintain generous line-heights for body copy to ensure readability against the dark background. 

**Labels** and navigation items should be uppercase with slight letter spacing to reinforce the organized, disciplined nature of the dojo.

## Layout & Spacing
The layout philosophy is based on a **Fixed Grid** with an emphasis on "negative space as a feature." 

- **The Grid:** A 12-column system for desktop, 4-column for mobile.
- **Section Gaps:** Vertical spacing between major content blocks is intentionally large (120px+) to allow the eye to rest and to give each "lesson" or "message" its own stage.
- **Alignment:** Use asymmetrical layouts occasionally to create a dynamic, "martial" movement across the screen, but keep text blocks strictly aligned to a hard left or right edge.
- **Responsiveness:** On mobile, margins reduce but padding within cards should remain generous to avoid a "cluttered" or "cheap" feel.

## Elevation & Depth
This design system avoids traditional shadows to maintain its minimalist and sharp character. Instead, depth is communicated through **Tonal Layering** and **Fine Outlines**:

- **Surfaces:** Use the Anthracite (#1A1A1A) color for cards to lift them slightly from the #0A0A0A background.
- **Borders:** Use a 1px solid border (#333333) for containers and input fields to define shape without adding visual weight.
- **Interactions:** When an element is hovered, use a subtle shift in background color or a primary burgundy border glow, rather than a shadow. 
- **Imagery:** Use background blurs only when text overlays cinematic imagery to ensure legibility while maintaining the "Glassmorphism" feel for navigation bars.

## Shapes
The shape language is dominated by **Sharpness**. Curves are kept to a minimum to reflect the precision of a blade or a strike. 

- **Standard Elements:** Buttons and cards use a very subtle 4px (Soft) radius to prevent the UI from feeling "dated" or "hostile," while still appearing predominantly rectangular.
- **Strict Elements:** Decorative lines, separators, and image containers should have a 0px radius (Sharp) to maintain a rigid, disciplined structure.

## Components

- **Buttons:** Primary buttons are Solid Burgundy (#8B0000) with White text, using `label-bold` typography. Secondary buttons are outlined in White with no fill. All buttons use a 4px corner radius.
- **Cards:** Background: #1A1A1A; Border: 1px solid #333333. Content within cards should have at least 32px of internal padding.
- **Input Fields:** Background: Transparent; Border: 1px solid #333333; Text: White. On focus, the border changes to Burgundy.
- **Chips/Badges:** Small, rectangular tags with #1A1A1A backgrounds and White uppercase text. Used for "Class Level" or "Style" indicators.
- **Lists:** Clean, undivided lists. Use a small Burgundy square (2x2px) as a bullet point to reinforce the brand color.
- **Hero Image Containers:** Large-scale, full-bleed imagery with a subtle gradient overlay (Top-to-bottom: Transparent to #0A0A0A) to allow text to sit comfortably at the bottom of the fold.
- **Specialty Component - "The Belt":** A thin horizontal divider that uses a color-coded strip (white, yellow, green, black) to indicate progression levels within class descriptions.